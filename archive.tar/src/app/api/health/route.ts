import { NextResponse } from "next/server";

export async function GET() {
  const healthData = {
    status: "healthy",
    service: "CodeSecure Security Auditor",
    version: "1.0.0",
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || "development",
    uptime: process.uptime(),
    security: {
      scanner: "active",
      aiEngine: "operational",
      database: "connected",
      auth: "secured"
    },
    features: {
      vulnerabilityScanning: "enabled",
      codeAnalysis: "enabled",
      dependencyAudit: "enabled",
      secretDetection: "enabled",
      aiCodeReview: "enabled",
      realTimeMonitoring: "enabled"
    },
    techStack: [
      "Next.js 15",
      "TypeScript 5",
      "Tailwind CSS 4",
      "shadcn/ui",
      "Prisma ORM",
      "NextAuth.js",
      "Zustand",
      "TanStack Query",
      "Socket.io",
      "AI Security Engine"
    ],
    endpoints: {
      health: "/api/health",
      security: "/api/security/scan",
      analysis: "/api/analysis/start",
      reports: "/api/reports/generate"
    }
  };

  return NextResponse.json(healthData);
}