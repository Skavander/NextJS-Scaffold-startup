import { NextResponse } from "next/server"

interface GitHubFile {
  name: string
  path: string
  sha: string
  size: number
  url: string
  html_url: string
  git_url: string
  download_url: string | null
  type: "file" | "dir"
  _links: {
    self: string
    git: string
    html: string
  }
}

interface GitHubRepoResponse {
  name: string
  full_name: string
  description: string | null
  default_branch: string
  language: string | null
  stargazers_count: number
  forks_count: number
  archived: boolean
  disabled: boolean
  private: boolean
}

export async function POST(request: Request) {
  try {
    const { repo } = await request.json()
    
    if (!repo) {
      return NextResponse.json({ error: "Repository is required" }, { status: 400 })
    }

    // Validate repository format (owner/repo)
    const repoRegex = /^[a-zA-Z0-9._-]+\/[a-zA-Z0-9._-]+$/
    if (!repoRegex.test(repo)) {
      return NextResponse.json({ 
        error: "Invalid repository format. Use 'owner/repo' format" 
      }, { status: 400 })
    }

    const [owner, repoName] = repo.split('/')
    
    // Check if GitHub token is available
    const githubToken = process.env.GITHUB_TOKEN
    if (!githubToken) {
      return NextResponse.json({ 
        error: "GitHub token not configured" 
      }, { status: 500 })
    }

    // Fetch repository information
    const repoResponse = await fetch(`https://api.github.com/repos/${owner}/${repoName}`, {
      headers: {
        'Authorization': `token ${githubToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    })

    if (!repoResponse.ok) {
      const errorData = await repoResponse.json()
      return NextResponse.json({ 
        error: `Failed to fetch repository: ${errorData.message}` 
      }, { status: repoResponse.status })
    }

    const repoData: GitHubRepoResponse = await repoResponse.json()

    // Check if repository is accessible
    if (repoData.archived || repoData.disabled || repoData.private) {
      return NextResponse.json({ 
        error: "Repository is not accessible (archived, disabled, or private)" 
      }, { status: 403 })
    }

    // Fetch repository contents
    const contentsResponse = await fetch(`https://api.github.com/repos/${owner}/${repoName}/git/trees/${repoData.default_branch}?recursive=1`, {
      headers: {
        'Authorization': `token ${githubToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    })

    if (!contentsResponse.ok) {
      return NextResponse.json({ 
        error: "Failed to fetch repository contents" 
      }, { status: contentsResponse.status })
    }

    const contentsData = await contentsResponse.json()
    
    // Transform GitHub response to file structure
    const transformFileStructure = (items: any[], basePath = ''): any[] => {
      const structure: any[] = []
      
      for (const item of items) {
        if (item.type === 'blob') {
          structure.push({
            id: item.path,
            name: item.path.split('/').pop(),
            type: 'file',
            path: item.path,
            size: item.size,
            sha: item.sha
          })
        } else if (item.type === 'tree') {
          const children = transformFileStructure(item.tree || [], item.path)
          structure.push({
            id: item.path,
            name: item.path.split('/').pop(),
            type: 'folder',
            path: item.path,
            children: children
          })
        }
      }
      
      return structure
    }

    const fileStructure = transformFileStructure(contentsData.tree || [])

    return NextResponse.json({
      success: true,
      repository: {
        name: repoData.name,
        fullName: repoData.full_name,
        description: repoData.description,
        defaultBranch: repoData.default_branch,
        language: repoData.language,
        stars: repoData.stargazers_count,
        forks: repoData.forks_count
      },
      fileStructure: fileStructure,
      totalFiles: fileStructure.filter(item => item.type === 'file').length,
      totalFolders: fileStructure.filter(item => item.type === 'folder').length
    })

  } catch (error) {
    console.error('GitHub API error:', error)
    return NextResponse.json({ 
      error: "Internal server error" 
    }, { status: 500 })
  }
}