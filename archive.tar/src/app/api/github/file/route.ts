import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { repo, filePath } = await request.json()
    
    if (!repo || !filePath) {
      return NextResponse.json({ error: "Repository and file path are required" }, { status: 400 })
    }

    const [owner, repoName] = repo.split('/')
    const githubToken = process.env.GITHUB_TOKEN

    if (!githubToken) {
      return NextResponse.json({ 
        error: "GitHub token not configured" 
      }, { status: 500 })
    }

    // Fetch file content
    const fileResponse = await fetch(`https://api.github.com/repos/${owner}/${repoName}/contents/${encodeURIComponent(filePath)}`, {
      headers: {
        'Authorization': `token ${githubToken}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    })

    if (!fileResponse.ok) {
      return NextResponse.json({ 
        error: "Failed to fetch file content" 
      }, { status: fileResponse.status })
    }

    const fileData = await fileResponse.json()
    
    // Decode base64 content
    const content = Buffer.from(fileData.content, 'base64').toString('utf-8')

    return NextResponse.json({
      success: true,
      file: {
        name: fileData.name,
        path: fileData.path,
        size: fileData.size,
        sha: fileData.sha,
        content: content,
        htmlUrl: fileData.html_url
      }
    })

  } catch (error) {
    console.error('GitHub file fetch error:', error)
    return NextResponse.json({ 
      error: "Internal server error" 
    }, { status: 500 })
  }
}