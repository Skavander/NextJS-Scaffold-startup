import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CodeSecure - AI-Powered Code Security Auditor & Revision Specialist",
  description: "Enterprise-grade code security auditing and revision platform powered by AI. Comprehensive vulnerability scanning, code analysis, and intelligent code review for modern development teams.",
  keywords: ["code security", "vulnerability scanning", "code audit", "AI security", "code review", "static analysis", "devsecops", "application security"],
  authors: [{ name: "CodeSecure Team" }],
  openGraph: {
    title: "CodeSecure - AI-Powered Code Security Auditor",
    description: "Enterprise-grade code security auditing and revision platform powered by artificial intelligence",
    url: "https://codesecure.ai",
    siteName: "CodeSecure",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "CodeSecure - AI-Powered Code Security Auditor",
    description: "Enterprise-grade code security auditing and revision platform powered by artificial intelligence",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
