"use client"

import { useState } from "react"
import Link from "next/link"
import { 
  ArrowRight, 
  Shield, 
  Eye, 
  GitBranch, 
  BarChart3,
  Lock,
  Search,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Users,
  Code,
  Database,
  Zap,
  Target,
  Activity,
  FileText,
  Settings,
  Bell,
  Download,
  Upload,
  RefreshCw
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { NavigationHeader } from "@/components/navigation-header"

export default function Home() {
  const [activeTab, setActiveTab] = useState("overview")

  // Mock security data
  const securityMetrics = {
    overallScore: 92,
    vulnerabilities: {
      critical: 2,
      high: 5,
      medium: 12,
      low: 23
    },
    scannedFiles: 1247,
    dependencies: 342,
    lastScan: "2 hours ago"
  }

  const recentScans = [
    { project: "Frontend App", status: "completed", score: 94, issues: 8, time: "2h ago" },
    { project: "API Service", status: "completed", score: 87, issues: 15, time: "5h ago" },
    { project: "Database Layer", status: "scanning", score: 0, issues: 0, time: "in progress" },
    { project: "Auth Module", status: "completed", score: 96, issues: 3, time: "1d ago" }
  ]

  const securityFeatures = [
    {
      icon: Shield,
      title: "Vulnerability Scanning",
      description: "Comprehensive security analysis with OWASP top 10 coverage",
      status: "active",
      color: "text-green-600"
    },
    {
      icon: Search,
      title: "Code Analysis",
      description: "Deep code inspection for security patterns and best practices",
      status: "active",
      color: "text-blue-600"
    },
    {
      icon: Database,
      title: "Dependency Audit",
      description: "Scan and monitor third-party packages for known vulnerabilities",
      status: "active",
      color: "text-purple-600"
    },
    {
      icon: Lock,
      title: "Secret Detection",
      description: "Automated detection of hardcoded secrets and credentials",
      status: "active",
      color: "text-orange-600"
    }
  ]

  const revisionFeatures = [
    {
      icon: GitBranch,
      title: "Smart Code Review",
      description: "AI-powered code review with contextual suggestions",
      status: "beta",
      color: "text-indigo-600"
    },
    {
      icon: Target,
      title: "Change Impact Analysis",
      description: "Predict and visualize the impact of code changes",
      status: "active",
      color: "text-teal-600"
    },
    {
      icon: Activity,
      title: "Real-time Monitoring",
      description: "Continuous monitoring of codebase health and security",
      status: "active",
      color: "text-cyan-600"
    },
    {
      icon: FileText,
      title: "Automated Reporting",
      description: "Generate comprehensive security and quality reports",
      status: "active",
      color: "text-pink-600"
    }
  ]

  return (
    <div className="min-h-screen bg-black">
      <NavigationHeader />

      {/* Hero Section */}
      <section className="relative overflow-hidden py-24 px-4 bg-gradient-to-br from-gray-900 via-black to-gray-800">
        <div className="container mx-auto">
          <div className="max-w-6xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4 bg-gradient-to-r from-gray-800 to-black text-white border-gray-700">
              🛡️ Enterprise-Grade Code Security
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-gray-200 via-white to-gray-400 bg-clip-text text-transparent">
              Secure Your Codebase
              <br />
              <span className="text-gray-300">With AI-Powered Intelligence</span>
            </h1>
            <p className="text-xl text-gray-400 mb-8 max-w-3xl mx-auto">
              Advanced security auditing and code revision platform that combines cutting-edge AI with 
              comprehensive security analysis to protect your applications from vulnerabilities.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button size="lg" className="bg-gradient-to-r from-gray-800 to-black hover:from-gray-700 hover:to-gray-900 border border-gray-700 text-white" asChild>
                <Link href="/audit">
                  Start Free Audit
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" className="border-gray-700 text-gray-300 hover:text-white hover:border-gray-600">
                View Demo
                <Eye className="ml-2 w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Security Overview Dashboard */}
      <section id="dashboard" className="py-24 px-4 bg-black">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
              Security Overview Dashboard
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Real-time insights into your codebase security posture
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Overall Security Score */}
            <Card className="lg:col-span-1 bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-white">
                  <Shield className="w-5 h-5 text-gray-400" />
                  <span>Security Score</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-4xl font-bold text-gray-200 mb-2">
                    {securityMetrics.overallScore}%
                  </div>
                  <Progress value={securityMetrics.overallScore} className="mb-4" />
                  <p className="text-sm text-gray-400">
                    Last scan: {securityMetrics.lastScan}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Vulnerability Summary */}
            <Card className="lg:col-span-2 bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-white">
                  <AlertTriangle className="w-5 h-5 text-gray-400" />
                  <span>Vulnerability Summary</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-400">{securityMetrics.vulnerabilities.critical}</div>
                    <div className="text-sm text-gray-400">Critical</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-400">{securityMetrics.vulnerabilities.high}</div>
                    <div className="text-sm text-gray-400">High</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-400">{securityMetrics.vulnerabilities.medium}</div>
                    <div className="text-sm text-gray-400">Medium</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">{securityMetrics.vulnerabilities.low}</div>
                    <div className="text-sm text-gray-400">Low</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Scans */}
          <Card className="bg-gray-900 border-gray-800">
            <CardHeader>
              <CardTitle className="flex items-center justify-between text-white">
                <span className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-gray-400" />
                  <span>Recent Security Scans</span>
                </span>
                <Button variant="outline" size="sm" className="border-gray-700 text-gray-300 hover:text-white hover:border-gray-600">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentScans.map((scan, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border border-gray-800 rounded-lg bg-gray-800/50">
                    <div className="flex items-center space-x-4">
                      <div className={`w-3 h-3 rounded-full ${
                        scan.status === 'completed' ? 'bg-green-500' : 
                        scan.status === 'scanning' ? 'bg-yellow-500' : 'bg-gray-500'
                      }`} />
                      <div>
                        <div className="font-medium text-white">{scan.project}</div>
                        <div className="text-sm text-gray-400">{scan.time}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      {scan.score > 0 && (
                        <div className="text-right">
                          <div className={`font-bold ${
                            scan.score >= 90 ? 'text-green-400' :
                            scan.score >= 70 ? 'text-yellow-400' : 'text-red-400'
                          }`}>
                            {scan.score}%
                          </div>
                          <div className="text-sm text-gray-400">{scan.issues} issues</div>
                        </div>
                      )}
                      <Badge variant={scan.status === 'completed' ? 'default' : 'secondary'} className={
                        scan.status === 'completed' ? 'bg-gray-700 text-white' : 'bg-gray-800 text-gray-300'
                      }>
                        {scan.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Security Audit Features */}
      <section id="security-audit" className="py-24 px-4 bg-gray-900">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
              Advanced Security Audit Features
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Comprehensive security analysis powered by cutting-edge AI and machine learning
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {securityFeatures.map((feature, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-black border-gray-800">
                <CardHeader>
                  <div className={`w-12 h-12 bg-gradient-to-br ${feature.color.replace('text-', 'bg-').replace('600', '900')} rounded-lg flex items-center justify-center mb-4`}>
                    <feature.icon className={`w-6 h-6 ${feature.color}`} />
                  </div>
                  <CardTitle className="group-hover:text-gray-200 transition-colors text-white">
                    {feature.title}
                  </CardTitle>
                  <Badge variant={feature.status === 'active' ? 'default' : 'secondary'} className="w-fit bg-gray-800 text-gray-300">
                    {feature.status}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base text-gray-400">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Code Revision Specialist */}
      <section id="code-revision" className="py-24 px-4 bg-black">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
              Code Revision Specialist
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              AI-powered code review and intelligent revision management
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {revisionFeatures.map((feature, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300 bg-gray-900 border-gray-800">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className={`w-12 h-12 bg-gradient-to-br ${feature.color.replace('text-', 'bg-').replace('600', '900')} rounded-lg flex items-center justify-center`}>
                      <feature.icon className={`w-6 h-6 ${feature.color}`} />
                    </div>
                    <Badge variant={feature.status === 'active' ? 'default' : 'secondary'} className="bg-gray-800 text-gray-300">
                      {feature.status}
                    </Badge>
                  </div>
                  <CardTitle className="group-hover:text-gray-200 transition-colors text-white">
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base text-gray-400">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Code Review Demo */}
          <Card className="bg-gradient-to-r from-gray-900 to-black border-gray-800">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-white">
                <Code className="w-5 h-5 text-gray-400" />
                <span>Live Code Review Demo</span>
              </CardTitle>
              <CardDescription className="text-gray-400">
                Experience AI-powered code review with real-time suggestions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-black text-gray-100 p-6 rounded-lg font-mono text-sm border border-gray-800">
                <div className="flex items-center space-x-2 mb-4">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-gray-400">security-review.js</span>
                </div>
                <div className="space-y-2">
                  <div><span className="text-purple-400">function</span> <span className="text-blue-400">validateInput</span>(<span className="text-orange-400">input</span>) {'{'}</div>
                  <div className="ml-4">{/* AI Suggestion: Add input sanitization */}</div>
                  <div className="ml-4"><span className="text-purple-400">if</span> (<span className="text-orange-400">typeof</span> input !== <span className="text-green-400">'string'</span>) {'{'}</div>
                  <div className="ml-8"><span className="text-purple-400">return</span> <span className="text-red-400">false</span>;</div>
                  <div className="ml-4">{'}'}</div>
                  <div className="ml-4"><span className="text-purple-400">return</span> input.<span className="text-blue-400">length</span> &gt; <span className="text-yellow-400">0</span>;</div>
                  <div>{'}'}</div>
                </div>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    AI detected 3 improvement opportunities for security and performance
                  </AlertDescription>
                </Alert>
                <Button>
                  Apply Suggestions
                  <CheckCircle className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Analytics Section */}
      <section id="analytics" className="py-24 px-4 bg-gray-900">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
              Advanced Analytics & Reporting
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Comprehensive insights into your codebase security and quality trends
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Security Trends */}
            <Card className="bg-black border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-white">
                  <TrendingUp className="w-5 h-5 text-gray-400" />
                  <span>Security Trends</span>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  30-day overview of security improvements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-300">Critical Issues</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-green-400">-75%</span>
                      <TrendingUp className="w-4 h-4 text-green-400" />
                    </div>
                  </div>
                  <Progress value={75} className="h-2" />
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-300">Security Score</span>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-green-400">+18%</span>
                      <TrendingUp className="w-4 h-4 text-green-400" />
                    </div>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>
              </CardContent>
            </Card>

            {/* Team Performance */}
            <Card className="bg-black border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-white">
                  <Users className="w-5 h-5 text-gray-400" />
                  <span>Team Performance</span>
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Development team security metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-300">Code Reviews</span>
                    <Badge variant="secondary" className="bg-gray-800 text-gray-300">247 completed</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-300">Security Training</span>
                    <Badge variant="default" className="bg-gray-800 text-white">94% completion</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-300">Avg. Fix Time</span>
                    <Badge variant="outline" className="border-gray-700 text-gray-300">2.3 days</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4 bg-black">
        <div className="container mx-auto">
          <Card className="bg-gradient-to-r from-gray-900 to-black border-gray-800">
            <CardContent className="text-center p-12">
              <Shield className="w-16 h-16 mx-auto mb-6 text-gray-400" />
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
                Ready to Secure Your Codebase?
              </h2>
              <p className="text-xl mb-8 max-w-2xl mx-auto text-gray-400">
                Join thousands of developers who are already protecting their applications with AI-powered security auditing.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" variant="secondary" className="bg-gray-800 text-white hover:bg-gray-700 border-gray-700">
                  Start Free Trial
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
                <Button size="lg" variant="outline" className="border-gray-700 text-gray-300 hover:text-white hover:border-gray-600">
                  Schedule Demo
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-12 px-4 bg-black">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-gray-900 via-black to-gray-800 rounded-lg flex items-center justify-center border border-gray-700">
                  <Shield className="w-5 h-5 text-white" />
                </div>
                <div>
                  <span className="font-bold text-xl text-white">CodeSecure</span>
                  <span className="block text-xs text-gray-400">Audit & Revision</span>
                </div>
              </div>
              <p className="text-gray-400">
                Enterprise-grade code security and auditing powered by AI intelligence.
              </p>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-semibold text-white">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="#security-audit" className="hover:text-white transition-colors">Security Audit</Link></li>
                <li><Link href="#code-revision" className="hover:text-white transition-colors">Code Revision</Link></li>
                <li><Link href="#analytics" className="hover:text-white transition-colors">Analytics</Link></li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-semibold text-white">Resources</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="#" className="hover:text-white transition-colors">Documentation</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">API Reference</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Security Blog</Link></li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-semibold text-white">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="#" className="hover:text-white transition-colors">About</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Security</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Contact</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 CodeSecure. Built with enterprise-grade security and AI-powered intelligence.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}