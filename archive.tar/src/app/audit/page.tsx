"use client"

import { useState, useEffect } from "react"
import { 
  ArrowLeft, 
  Github, 
  Upload, 
  FileText, 
  Settings, 
  User, 
  Download,
  Search,
  FolderOpen,
  File,
  ChevronRight,
  ChevronDown,
  X,
  Play,
  CheckCircle,
  AlertTriangle,
  Info,
  RefreshCw,
  GitBranch,
  GitPullRequest,
  Terminal,
  Maximize2,
  Minimize2
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Input } from "@/components/ui/input"
import Link from "next/link"

interface FileNode {
  id: string
  name: string
  type: 'file' | 'folder'
  path: string
  children?: FileNode[]
  hasIssues?: boolean
  severity?: 'critical' | 'high' | 'medium' | 'low'
}

interface SecurityIssue {
  id: string
  file: string
  line: number
  severity: 'critical' | 'high' | 'medium' | 'low'
  title: string
  description: string
  suggestion: string
  code: string
  fixedCode: string
}

interface AnalysisLog {
  id: string
  timestamp: string
  message: string
  type: 'info' | 'warning' | 'error' | 'success'
}

export default function AuditDashboard() {
  const [githubRepo, setGithubRepo] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const [selectedFile, setSelectedFile] = useState<string | null>(null)
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set())
  const [activeTab, setActiveTab] = useState("report")
  const [analysisLogs, setAnalysisLogs] = useState<AnalysisLog[]>([])
  const [securityIssues, setSecurityIssues] = useState<SecurityIssue[]>([])
  const [currentFileContent, setCurrentFileContent] = useState("")

  // Mock file structure
  const fileStructure: FileNode[] = [
    {
      id: "src",
      name: "src",
      type: "folder",
      path: "src",
      children: [
        {
          id: "components",
          name: "components",
          type: "folder",
          path: "src/components",
          children: [
            { id: "header.tsx", name: "header.tsx", type: "file", path: "src/components/header.tsx", hasIssues: true, severity: "high" },
            { id: "auth.tsx", name: "auth.tsx", type: "file", path: "src/components/auth.tsx", hasIssues: true, severity: "critical" },
            { id: "dashboard.tsx", name: "dashboard.tsx", type: "file", path: "src/components/dashboard.tsx" }
          ]
        },
        {
          id: "lib",
          name: "lib",
          type: "folder",
          path: "src/lib",
          children: [
            { id: "auth.ts", name: "auth.ts", type: "file", path: "src/lib/auth.ts", hasIssues: true, severity: "medium" },
            { id: "database.ts", name: "database.ts", type: "file", path: "src/lib/database.ts", hasIssues: true, severity: "high" }
          ]
        },
        { id: "app.tsx", name: "app.tsx", type: "file", path: "src/app.tsx" },
        { id: "index.ts", name: "index.ts", type: "file", path: "src/index.ts" }
      ]
    },
    {
      id: "package.json",
      name: "package.json",
      type: "file",
      path: "package.json",
      hasIssues: true,
      severity: "medium"
    },
    {
      id: "README.md",
      name: "README.md",
      type: "file",
      path: "README.md"
    }
  ]

  const mockSecurityIssues: SecurityIssue[] = [
    {
      id: "1",
      file: "src/components/auth.tsx",
      line: 45,
      severity: "critical",
      title: "Hardcoded API Key",
      description: "API key is hardcoded in the source code",
      suggestion: "Move API key to environment variables",
      code: "const apiKey = 'sk-1234567890abcdef';",
      fixedCode: "const apiKey = process.env.API_KEY;"
    },
    {
      id: "2",
      file: "src/lib/database.ts",
      line: 23,
      severity: "high",
      title: "SQL Injection Vulnerability",
      description: "User input is directly concatenated into SQL query",
      suggestion: "Use parameterized queries",
      code: "const query = 'SELECT * FROM users WHERE name = \\'' + userName + '\\''';",
      fixedCode: "const query = 'SELECT * FROM users WHERE name = ?';"
    },
    {
      id: "3",
      file: "src/components/header.tsx",
      line: 12,
      severity: "high",
      title: "XSS Vulnerability",
      description: "User input is rendered without sanitization",
      suggestion: "Use DOMPurify or similar sanitization library",
      code: "<div dangerouslySetInnerHTML={{ __html: userInput }} />",
      fixedCode: "<div>{sanitizedInput}</div>"
    },
    {
      id: "4",
      file: "src/lib/auth.ts",
      line: 67,
      severity: "medium",
      title: "Weak Password Policy",
      description: "Password requirements are too lenient",
      suggestion: "Implement stronger password requirements",
      code: "if (password.length >= 6) {",
      fixedCode: "if (password.length >= 12 && /[A-Z]/.test(password) && /[0-9]/.test(password)) {"
    },
    {
      id: "5",
      file: "package.json",
      line: 15,
      severity: "medium",
      title: "Outdated Dependency",
      description: "Package has known security vulnerabilities",
      suggestion: "Update to latest version",
      code: "\"lodash\": \"^4.17.15\"",
      fixedCode: "\"lodash\": \"^4.17.21\""
    }
  ]

  const severityColors = {
    critical: "bg-red-500",
    high: "bg-orange-500", 
    medium: "bg-yellow-500",
    low: "bg-blue-500"
  }

  const severityLabels = {
    critical: "Critical",
    high: "High",
    medium: "Medium", 
    low: "Low"
  }

  const toggleFolder = (folderId: string) => {
    const newExpanded = new Set(expandedFolders)
    if (newExpanded.has(folderId)) {
      newExpanded.delete(folderId)
    } else {
      newExpanded.add(folderId)
    }
    setExpandedFolders(newExpanded)
  }

  const handleAnalyze = () => {
    if (!githubRepo.trim()) return
    
    setIsAnalyzing(true)
    setAnalysisProgress(0)
    setAnalysisLogs([])
    setSecurityIssues([])

    // Simulate analysis process
    const logs: AnalysisLog[] = [
      { id: "1", timestamp: new Date().toISOString(), message: "Starting security analysis...", type: "info" },
      { id: "2", timestamp: new Date().toISOString(), message: "Cloning repository...", type: "info" },
      { id: "3", timestamp: new Date().toISOString(), message: "Analyzing file structure...", type: "info" },
      { id: "4", timestamp: new Date().toISOString(), message: "Scanning for vulnerabilities...", type: "info" },
      { id: "5", timestamp: new Date().toISOString(), message: "Found 5 security issues", type: "warning" },
      { id: "6", timestamp: new Date().toISOString(), message: "Generating recommendations...", type: "info" },
      { id: "7", timestamp: new Date().toISOString(), message: "Analysis completed successfully", type: "success" }
    ]

    logs.forEach((log, index) => {
      setTimeout(() => {
        setAnalysisLogs(prev => [...prev, log])
        setAnalysisProgress(((index + 1) / logs.length) * 100)
        
        if (index === logs.length - 1) {
          setTimeout(() => {
            setIsAnalyzing(false)
            setSecurityIssues(mockSecurityIssues)
          }, 500)
        }
      }, (index + 1) * 800)
    })
  }

  const selectFile = (filePath: string) => {
    setSelectedFile(filePath)
    // Mock file content based on path
    if (filePath.includes("auth.tsx")) {
      setCurrentFileContent(`import { useState } from 'react'

export function AuthComponent() {
  const [userInput, setUserInput] = useState('')
  
  // CRITICAL ISSUE: Hardcoded API key
  const apiKey = 'sk-1234567890abcdef'
  
  const handleSubmit = () => {
    fetch('/api/auth', {
      headers: {
        'Authorization': \`Bearer \${apiKey}\`
      })
  }
  
  return (
    <div>
      {/* HIGH ISSUE: XSS vulnerability */}
      <div dangerouslySetInnerHTML={{ __html: userInput }} />
    </div>
  )
}`)
    } else if (filePath.includes("database.ts")) {
      setCurrentFileContent(`import { Pool } from 'pg'

const pool = new Pool()

export function getUser(userName: string) {
  // HIGH ISSUE: SQL injection vulnerability
  const query = 'SELECT * FROM users WHERE name = \\'' + userName + '\\''
  
  return pool.query(query)
}`)
    } else {
      setCurrentFileContent(`// File content for ${filePath}
// This is a mock file content for demonstration purposes.
// In a real application, this would show the actual file content
// with syntax highlighting and security issue annotations.`)
    }
  }

  const renderFileTree = (nodes: FileNode[], depth = 0) => {
    return nodes.map(node => {
      if (node.type === 'folder') {
        const isExpanded = expandedFolders.has(node.id)
        return (
          <div key={node.id}>
            <div 
              className="flex items-center space-x-2 p-1 hover:bg-gray-800 rounded cursor-pointer"
              onClick={() => toggleFolder(node.id)}
              style={{ paddingLeft: `${depth * 12 + 8}px` }}
            >
              {isExpanded ? (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronRight className="w-4 h-4 text-gray-400" />
              )}
              <FolderOpen className="w-4 h-4 text-gray-400" />
              <span className="text-gray-300 text-sm">{node.name}</span>
            </div>
            {isExpanded && node.children && (
              <div>
                {renderFileTree(node.children, depth + 1)}
              </div>
            )}
          </div>
        )
      } else {
        return (
          <div 
            key={node.id}
            className={`flex items-center space-x-2 p-1 hover:bg-gray-800 rounded cursor-pointer ${
              selectedFile === node.path ? 'bg-gray-800' : ''
            }`}
            onClick={() => selectFile(node.path)}
            style={{ paddingLeft: `${depth * 12 + 8}px` }}
          >
            <File className="w-4 h-4 text-gray-400" />
            <span className="text-gray-300 text-sm flex-1">{node.name}</span>
            {node.hasIssues && (
              <div className={`w-2 h-2 rounded-full ${severityColors[node.severity!]}`} />
            )}
          </div>
        )
      }
    })
  }

  return (
    <div className="min-h-screen bg-black text-gray-300">
      {/* Top Navigation Bar */}
      <header className="h-14 border-b border-gray-800 flex items-center px-4 bg-black">
        <div className="flex items-center space-x-4 flex-1">
          <Link href="/" className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>
          <div className="h-4 w-px bg-gray-700"></div>
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-gray-900 via-black to-gray-800 rounded-lg flex items-center justify-center border border-gray-700">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <div>
              <span className="font-bold text-white">SecureCode Auditor</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 flex-1 max-w-md">
            <Input
              placeholder="Enter GitHub repository (e.g., username/repo)"
              value={githubRepo}
              onChange={(e) => setGithubRepo(e.target.value)}
              className="bg-gray-900 border-gray-700 text-white placeholder-gray-500"
            />
            <Button 
              onClick={handleAnalyze}
              disabled={isAnalyzing || !githubRepo.trim()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isAnalyzing ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Play className="w-4 h-4" />
              )}
              Analyze
            </Button>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <Button variant="outline" size="sm" className="border-gray-700 text-gray-300 hover:text-white">
            <Upload className="w-4 h-4 mr-2" />
            Upload
          </Button>
          <Button variant="outline" size="sm" className="border-gray-700 text-gray-300 hover:text-white">
            <FileText className="w-4 h-4 mr-2" />
            Paste Code
          </Button>
          <Button variant="outline" size="sm" className="border-gray-700 text-gray-300 hover:text-white">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            <Settings className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            <User className="w-4 h-4" />
          </Button>
        </div>
      </header>

      <div className="flex h-[calc(100vh-3.5rem)]">
        {/* Left Sidebar - File Explorer */}
        <div className="w-64 border-r border-gray-800 bg-gray-900 flex flex-col">
          <div className="p-4 border-b border-gray-800">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
              <Input
                placeholder="Search files..."
                className="pl-10 bg-gray-800 border-gray-700 text-white placeholder-gray-500"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2">
            <div className="text-xs text-gray-500 uppercase tracking-wider mb-2 px-2">Project Explorer</div>
            {renderFileTree(fileStructure)}
          </div>
        </div>

        {/* Main Panel - Code Editor */}
        <div className="flex-1 flex flex-col bg-black">
          {/* File Tabs */}
          <div className="h-10 border-b border-gray-800 flex items-center bg-gray-900">
            {selectedFile ? (
              <div className="flex items-center space-x-2 px-4 h-full border-r border-gray-800 bg-black">
                <File className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-white">{selectedFile.split('/').pop()}</span>
                <button 
                  onClick={() => setSelectedFile(null)}
                  className="text-gray-500 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <div className="px-4 text-sm text-gray-500">
                No file selected
              </div>
            )}
          </div>

          {/* Code Editor Area */}
          <div className="flex-1 overflow-auto">
            {selectedFile ? (
              <div className="h-full">
                <pre className="p-4 text-sm font-mono text-gray-300 overflow-auto h-full">
                  <code>{currentFileContent}</code>
                </pre>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <File className="w-16 h-16 mx-auto mb-4 text-gray-600" />
                  <p className="text-lg mb-2">Select a file to view</p>
                  <p className="text-sm">Choose a file from the project explorer to start reviewing code</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Sidebar - Audit Tools */}
        <div className="w-80 border-l border-gray-800 bg-gray-900 flex flex-col">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-3 bg-gray-900 border-b border-gray-800">
              <TabsTrigger value="report" className="text-xs">Report</TabsTrigger>
              <TabsTrigger value="suggestions" className="text-xs">Suggestions</TabsTrigger>
              <TabsTrigger value="practices" className="text-xs">Best Practices</TabsTrigger>
            </TabsList>
            
            <div className="flex-1 overflow-y-auto">
              <TabsContent value="report" className="p-4 space-y-3">
                <h3 className="font-semibold text-white mb-3">Security Issues</h3>
                {securityIssues.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    <CheckCircle className="w-12 h-12 mx-auto mb-2 text-green-500" />
                    <p>No security issues found</p>
                  </div>
                ) : (
                  securityIssues.map(issue => (
                    <Card key={issue.id} className="bg-gray-800 border-gray-700">
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-sm flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${severityColors[issue.severity]}`} />
                            <span className="text-white">{issue.title}</span>
                          </CardTitle>
                          <Badge variant="secondary" className={`text-xs ${
                            issue.severity === 'critical' ? 'bg-red-900 text-red-200' :
                            issue.severity === 'high' ? 'bg-orange-900 text-orange-200' :
                            issue.severity === 'medium' ? 'bg-yellow-900 text-yellow-200' :
                            'bg-blue-900 text-blue-200'
                          }`}>
                            {severityLabels[issue.severity]}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="text-xs text-gray-400 mb-2">
                          {issue.file}:{issue.line}
                        </p>
                        <p className="text-sm text-gray-300 mb-2">
                          {issue.description}
                        </p>
                        <Button 
                          size="sm" 
                          className="w-full text-xs"
                          onClick={() => selectFile(issue.file)}
                        >
                          View Code
                        </Button>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>
              
              <TabsContent value="suggestions" className="p-4 space-y-3">
                <h3 className="font-semibold text-white mb-3">Recommended Fixes</h3>
                {securityIssues.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    <Info className="w-12 h-12 mx-auto mb-2 text-blue-500" />
                    <p>No suggestions available</p>
                  </div>
                ) : (
                  securityIssues.map(issue => (
                    <Card key={issue.id} className="bg-gray-800 border-gray-700">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm text-white">{issue.title}</CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="text-xs text-gray-400 mb-2">Suggestion:</p>
                        <p className="text-sm text-gray-300 mb-3">{issue.suggestion}</p>
                        <div className="bg-black p-2 rounded mb-2">
                          <p className="text-xs text-red-400 mb-1">Before:</p>
                          <code className="text-xs text-gray-300">{issue.code}</code>
                        </div>
                        <div className="bg-black p-2 rounded">
                          <p className="text-xs text-green-400 mb-1">After:</p>
                          <code className="text-xs text-gray-300">{issue.fixedCode}</code>
                        </div>
                        <Button size="sm" className="w-full mt-3 text-xs">
                          <GitPullRequest className="w-3 h-3 mr-1" />
                          Create PR
                        </Button>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>
              
              <TabsContent value="practices" className="p-4 space-y-3">
                <h3 className="font-semibold text-white mb-3">Best Practices</h3>
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-white">Security Guidelines</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <ul className="text-sm text-gray-300 space-y-2">
                      <li>• Use environment variables for secrets</li>
                      <li>• Implement input validation</li>
                      <li>• Use parameterized queries</li>
                      <li>• Keep dependencies updated</li>
                      <li>• Implement proper authentication</li>
                      <li>• Use HTTPS in production</li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-white">Code Quality</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <ul className="text-sm text-gray-300 space-y-2">
                      <li>• Write clear, documented code</li>
                      <li>• Follow consistent naming conventions</li>
                      <li>• Implement error handling</li>
                      <li>• Use TypeScript for type safety</li>
                      <li>• Write unit tests</li>
                      <li>• Follow DRY principles</li>
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>

      {/* Bottom Panel - Console/Logs */}
      <div className="h-32 border-t border-gray-800 bg-gray-900">
        <div className="h-8 border-b border-gray-800 flex items-center px-4">
          <Terminal className="w-4 h-4 text-gray-400 mr-2" />
          <span className="text-sm text-gray-400">Analysis Console</span>
          <div className="flex-1" />
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            <Maximize2 className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 font-mono text-xs">
          {analysisLogs.length === 0 ? (
            <div className="text-gray-500">Waiting for analysis to start...</div>
          ) : (
            analysisLogs.map(log => (
              <div key={log.id} className="flex items-center space-x-2 mb-1">
                <span className="text-gray-500">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                {log.type === 'error' && <span className="text-red-400">[ERROR]</span>}
                {log.type === 'warning' && <span className="text-yellow-400">[WARN]</span>}
                {log.type === 'success' && <span className="text-green-400">[SUCCESS]</span>}
                {log.type === 'info' && <span className="text-blue-400">[INFO]</span>}
                <span className="text-gray-300">{log.message}</span>
              </div>
            ))
          )}
        </div>
        {isAnalyzing && (
          <div className="px-4 pb-2">
            <Progress value={analysisProgress} className="h-1" />
            <div className="text-xs text-gray-500 mt-1">
              Analyzing... {Math.round(analysisProgress)}%
            </div>
          </div>
        )}
      </div>
    </div>
  )
}