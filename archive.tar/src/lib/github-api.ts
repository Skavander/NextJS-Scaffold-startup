export interface GitHubFile {
  name: string
  path: string
  sha: string
  size: number
  url: string
  html_url: string
  git_url: string
  download_url: string | null
  type: 'file' | 'dir'
  content?: string
  encoding?: string
}

export interface GitHubRepository {
  name: string
  full_name: string
  description: string
  clone_url: string
  default_branch: string
  language: string
  stargazers_count: number
  forks_count: number
}

export interface SecurityIssue {
  id: string
  file: string
  line: number
  severity: 'critical' | 'high' | 'medium' | 'low'
  title: string
  description: string
  suggestion: string
  code: string
  fixedCode: string
  rule: string
  category: string
}

class GitHubAPI {
  private baseUrl: string = 'https://api.github.com'

  async getRepository(owner: string, repo: string): Promise<GitHubRepository> {
    const response = await fetch(`${this.baseUrl}/repos/${owner}/${repo}`, {
      headers: {
        'Accept': 'application/vnd.github.v3+json',
      }
    })

    if (!response.ok) {
      throw new Error(`Repository not found: ${owner}/${repo}`)
    }

    return response.json()
  }

  async getRepositoryContents(owner: string, repo: string, path: string = '', branch?: string): Promise<GitHubFile[]> {
    const branchParam = branch ? `?ref=${branch}` : ''
    const response = await fetch(`${this.baseUrl}/repos/${owner}/${repo}/contents/${path}${branchParam}`, {
      headers: {
        'Accept': 'application/vnd.github.v3+json',
      }
    })

    if (!response.ok) {
      throw new Error(`Failed to fetch contents: ${path}`)
    }

    return response.json()
  }

  async getFileContent(owner: string, repo: string, path: string, branch?: string): Promise<string> {
    const response = await fetch(`${this.baseUrl}/repos/${owner}/${repo}/contents/${path}${branch ? `?ref=${branch}` : ''}`, {
      headers: {
        'Accept': 'application/vnd.github.v3+json',
      }
    })

    if (!response.ok) {
      throw new Error(`Failed to fetch file: ${path}`)
    }

    const data = await response.json()
    
    if (data.content) {
      return atob(data.content.replace(/\n/g, ''))
    }
    
    return ''
  }

  async buildFileTree(owner: string, repo: string, branch?: string): Promise<GitHubFile[]> {
    const allFiles: GitHubFile[] = []
    
    const processDirectory = async (path: string = '') => {
      try {
        const contents = await this.getRepositoryContents(owner, repo, path, branch)
        
        for (const item of contents) {
          if (item.type === 'dir') {
            await processDirectory(item.path)
          } else {
            allFiles.push(item)
          }
        }
      } catch (error) {
        console.warn(`Failed to process directory ${path}:`, error)
      }
    }

    await processDirectory()
    return allFiles
  }
}

export const githubAPI = new GitHubAPI()