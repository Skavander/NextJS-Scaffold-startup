import { SecurityIssue } from './github-api'

interface SecurityRule {
  id: string
  name: string
  description: string
  severity: 'critical' | 'high' | 'medium' | 'low'
  category: string
  pattern: RegExp
  test: (content: string, filePath: string) => boolean
  getSuggestion: (match: RegExpMatchArray, content: string) => { suggestion: string; fixedCode: string }
}

const securityRules: SecurityRule[] = [
  // Hardcoded API Keys
  {
    id: 'hardcoded-api-key',
    name: 'Hardcoded API Key',
    description: 'API key or secret is hardcoded in source code',
    severity: 'critical',
    category: 'Secrets Management',
    pattern: /(?:api[_-]?key|secret|password|token)\s*[:=]\s*['"`]([a-zA-Z0-9_\-]{16,})['"`]/gi,
    test: (content, filePath) => {
      return securityRules[0].pattern.test(content) && 
             !filePath.includes('env.example') && 
             !filePath.includes('.env')
    },
    getSuggestion: (match, content) => ({
      suggestion: 'Move API keys and secrets to environment variables',
      fixedCode: content.replace(match[0], `process.env.${match[1].toUpperCase()}`)
    })
  },

  // SQL Injection
  {
    id: 'sql-injection',
    name: 'SQL Injection Vulnerability',
    description: 'User input is directly concatenated into SQL queries',
    severity: 'high',
    category: 'Injection',
    pattern: /(?:SELECT|INSERT|UPDATE|DELETE|FROM|WHERE)\s+[^'"]*\+[^'"]*\s*['"`][^'"]*\+[^'"]*\s*['"`]/gi,
    test: (content) => securityRules[1].pattern.test(content),
    getSuggestion: () => ({
      suggestion: 'Use parameterized queries or prepared statements',
      fixedCode: 'Use parameterized queries with placeholders (?)'
    })
  },

  // XSS Vulnerability
  {
    id: 'xss-vulnerability',
    name: 'XSS Vulnerability',
    description: 'User input is rendered without proper sanitization',
    severity: 'high',
    category: 'Cross-Site Scripting',
    pattern: /dangerouslySetInnerHTML|innerHTML\s*=|outerHTML\s*=/gi,
    test: (content) => securityRules[2].pattern.test(content),
    getSuggestion: () => ({
      suggestion: 'Use DOMPurify or proper text rendering instead of innerHTML',
      fixedCode: 'Use textContent or DOMPurify.sanitize() for user input'
    })
  },

  // Hardcoded Passwords
  {
    id: 'hardcoded-password',
    name: 'Hardcoded Password',
    description: 'Password is hardcoded in source code',
    severity: 'critical',
    category: 'Authentication',
    pattern: /password\s*[:=]\s*['"`]([^'"`]{4,})['"`]/gi,
    test: (content) => securityRules[3].pattern.test(content),
    getSuggestion: (match, content) => ({
      suggestion: 'Never hardcode passwords. Use secure authentication methods.',
      fixedCode: content.replace(match[0], 'process.env.PASSWORD')
    })
  },

  // Weak Crypto
  {
    id: 'weak-crypto',
    name: 'Weak Cryptographic Algorithm',
    description: 'Weak or deprecated cryptographic algorithm detected',
    severity: 'medium',
    category: 'Cryptography',
    pattern: /(?:md5|sha1|des|rc4)\s*\(/gi,
    test: (content) => securityRules[4].pattern.test(content),
    getSuggestion: () => ({
      suggestion: 'Use stronger cryptographic algorithms like SHA-256, bcrypt, or Argon2',
      fixedCode: 'Replace with stronger algorithms like SHA-256, bcrypt, or Argon2'
    })
  },

  // Insecure Random
  {
    id: 'insecure-random',
    name: 'Insecure Random Number Generation',
    description: 'Using Math.random() for security-sensitive operations',
    severity: 'medium',
    category: 'Randomness',
    pattern: /Math\.random\(\)/gi,
    test: (content, filePath) => {
      return securityRules[5].pattern.test(content) && 
             (filePath.includes('auth') || filePath.includes('crypto') || filePath.includes('token'))
    },
    getSuggestion: () => ({
      suggestion: 'Use crypto.randomBytes() or Web Crypto API for security-sensitive randomness',
      fixedCode: 'Use crypto.randomBytes() or window.crypto.getRandomValues()'
    })
  },

  // eval() Usage
  {
    id: 'eval-usage',
    name: 'eval() Usage',
    description: 'Use of eval() can lead to code injection attacks',
    severity: 'high',
    category: 'Code Injection',
    pattern: /eval\s*\(/gi,
    test: (content) => securityRules[6].pattern.test(content),
    getSuggestion: () => ({
      suggestion: 'Avoid using eval(). Use safer alternatives like JSON.parse() or Function constructor',
      fixedCode: 'Replace eval() with safer alternatives'
    })
  },

  // Path Traversal
  {
    id: 'path-traversal',
    name: 'Path Traversal Vulnerability',
    description: 'User input is used in file paths without validation',
    severity: 'high',
    category: 'File System',
    pattern: /(?:fs\.readFile|fs\.writeFile|require|import)\s*\([^)]*\+[^)]*\)/gi,
    test: (content) => securityRules[7].pattern.test(content),
    getSuggestion: () => ({
      suggestion: 'Validate and sanitize user input used in file paths',
      fixedCode: 'Use path.resolve() and validate input paths'
    })
  },

  // Insecure HTTP Headers
  {
    id: 'insecure-headers',
    name: 'Insecure HTTP Headers',
    description: 'Missing security headers or insecure configurations',
    severity: 'medium',
    category: 'HTTP Security',
    pattern: /Content-Security-Policy|X-Frame-Options|X-Content-Type-Options/gi,
    test: (content, filePath) => {
      const hasSecurityHeaders = securityRules[8].pattern.test(content)
      return !hasSecurityHeaders && (filePath.includes('server') || filePath.includes('app') || filePath.includes('middleware'))
    },
    getSuggestion: () => ({
      suggestion: 'Add security headers like CSP, X-Frame-Options, and X-Content-Type-Options',
      fixedCode: 'Add security headers to your HTTP response'
    })
  }
]

export class SecurityScanner {
  private rules: SecurityRule[] = securityRules

  async scanFile(content: string, filePath: string): Promise<SecurityIssue[]> {
    const issues: SecurityIssue[] = []

    for (const rule of this.rules) {
      try {
        if (rule.test(content, filePath)) {
          const matches = Array.from(content.matchAll(rule.pattern))
          
          for (let i = 0; i < matches.length; i++) {
            const match = matches[i]
            const lines = content.substring(0, match.index).split('\n')
            const lineNumber = lines.length
            
            const { suggestion, fixedCode } = rule.getSuggestion(match, content)
            
            issues.push({
              id: `${rule.id}-${i}`,
              file: filePath,
              line: lineNumber,
              severity: rule.severity,
              title: rule.name,
              description: rule.description,
              suggestion,
              code: match[0],
              fixedCode,
              rule: rule.id,
              category: rule.category
            })
          }
        }
      } catch (error) {
        console.warn(`Error applying rule ${rule.id}:`, error)
      }
    }

    return issues
  }

  async scanRepository(files: Array<{ path: string; content: string }>): Promise<SecurityIssue[]> {
    const allIssues: SecurityIssue[] = []

    for (const file of files) {
      try {
        const fileIssues = await this.scanFile(file.content, file.path)
        allIssues.push(...fileIssues)
      } catch (error) {
        console.warn(`Error scanning file ${file.path}:`, error)
      }
    }

    // Deduplicate issues that might be found by multiple rules
    const uniqueIssues = allIssues.filter((issue, index, self) => 
      index === self.findIndex(i => i.file === issue.file && i.line === issue.line && i.rule === issue.rule)
    )

    return uniqueIssues.sort((a, b) => {
      const severityOrder = { critical: 4, high: 3, medium: 2, low: 1 }
      return severityOrder[b.severity] - severityOrder[a.severity]
    })
  }

  getSupportedRules(): SecurityRule[] {
    return this.rules
  }

  getSeverityStats(issues: SecurityIssue[]): {
    const stats = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
      total: issues.length
    }

    issues.forEach(issue => {
      stats[issue.severity]++
    })

    return stats
  }
}

export const securityScanner = new SecurityScanner()