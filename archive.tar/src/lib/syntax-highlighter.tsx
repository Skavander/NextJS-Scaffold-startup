'use client'

import React from 'react'

interface SyntaxHighlighterProps {
  code: string
  language: string
  highlights?: Array<{ line: number; type: 'error' | 'warning' | 'info' }>
}

export function SyntaxHighlighter({ code, language, highlights = [] }: SyntaxHighlighterProps) {
  const getLanguageClass = (lang: string) => {
    switch (lang.toLowerCase()) {
      case 'javascript':
      case 'jsx':
        return 'language-javascript'
      case 'typescript':
      case 'tsx':
        return 'language-typescript'
      case 'python':
        return 'language-python'
      case 'java':
        return 'language-java'
      case 'css':
        return 'language-css'
      case 'html':
        return 'language-html'
      case 'json':
        return 'language-json'
      case 'sql':
        return 'language-sql'
      case 'markdown':
        return 'language-markdown'
      default:
        return 'language-text'
    }
  }

  const highlightKeywords = (line: string, language: string): string => {
    if (language === 'javascript' || language === 'typescript' || language === 'jsx' || language === 'tsx') {
      // JavaScript/TypeScript keywords
      const keywords = [
        'function', 'const', 'let', 'var', 'if', 'else', 'for', 'while', 'do', 'switch', 'case',
        'break', 'continue', 'return', 'try', 'catch', 'finally', 'throw', 'new', 'class',
        'extends', 'super', 'import', 'export', 'default', 'async', 'await', 'from', 'as',
        'typeof', 'instanceof', 'void', 'null', 'undefined', 'true', 'false', 'this', 'in'
      ]

      // Built-in objects and methods
      const builtIns = [
        'console', 'Math', 'Date', 'Array', 'Object', 'String', 'Number', 'Boolean',
        'RegExp', 'Promise', 'Set', 'Map', 'WeakSet', 'WeakMap', 'JSON', 'parseInt',
        'parseFloat', 'isNaN', 'isFinite', 'encodeURI', 'decodeURI', 'setTimeout', 'clearTimeout'
      ]

      let highlighted = line

      // Highlight strings
      highlighted = highlighted.replace(/(['"`])((?:(?!\1)[^\\]|\\.)*)(\1)/g, '<span class="string">$1$2$3</span>')

      // Highlight numbers
      highlighted = highlighted.replace(/\b(\d+)\b/g, '<span class="number">$1</span>')

      // Highlight keywords
      keywords.forEach(keyword => {
        const regex = new RegExp(`\\b${keyword}\\b`, 'g')
        highlighted = highlighted.replace(regex, `<span class="keyword">${keyword}</span>`)
      })

      // Highlight built-ins
      builtIns.forEach(builtIn => {
        const regex = new RegExp(`\\b${builtIn}\\b`, 'g')
        highlighted = highlighted.replace(regex, `<span class="built-in">${builtIn}</span>`)
      })

      // Highlight comments
      highlighted = highlighted.replace(/(\/\/.*$)/gm, '<span class="comment">$1</span>')
      highlighted = highlighted.replace(/(\/\*[\s\S]*?\*\/)/gm, '<span class="comment">$1</span>')

      return highlighted
    }

    if (language === 'python') {
      const keywords = ['def', 'class', 'if', 'elif', 'else', 'for', 'while', 'try', 'except', 'finally', 'import', 'from', 'as', 'return', 'yield', 'with', 'pass', 'break', 'continue', 'and', 'or', 'not', 'in', 'is', 'lambda', 'global', 'nonlocal', 'assert', 'del', 'raise']
      
      let highlighted = line

      // Highlight strings
      highlighted = highlighted.replace(/(['"`])((?:(?!\1)[^\\]|\\.)*)(\1)/g, '<span class="string">$1$2$3</span>')
      
      // Highlight numbers
      highlighted = highlighted.replace(/\b(\d+)\b/g, '<span class="number">$1</span>')
      
      // Highlight keywords
      keywords.forEach(keyword => {
        const regex = new RegExp(`\\b${keyword}\\b`, 'g')
        highlighted = highlighted.replace(regex, `<span class="keyword">${keyword}</span>`)
      })

      // Highlight comments
      highlighted = highlighted.replace(/(#.*$)/gm, '<span class="comment">$1</span>')

      return highlighted
    }

    return line
  }

  const getLineClass = (lineNumber: number): string => {
    const highlight = highlights.find(h => h.line === lineNumber)
    if (highlight) {
      return `line-${highlight.type}`
    }
    return ''
  }

  const lines = code.split('\n')

  return (
    <div className={`syntax-highlighter ${getLanguageClass(language)}`}>
      <pre className="text-sm">
        {lines.map((line, index) => (
          <div key={index} className={`line ${getLineClass(index + 1)}`}>
            <span className="line-number">{index + 1}</span>
            <span 
              className="line-content" 
              dangerouslySetInnerHTML={{ 
                __html: highlightKeywords(line, language) 
              }} 
            />
          </div>
        ))}
      </pre>
    </div>
  )
}